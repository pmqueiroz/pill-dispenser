# ShiftOutMega
Biblioteca para controlar portas adicionais OUTPUT do Arduino utilizando o CI registrador de deslocamento 74HC595

Autor    : Fellipe Couto [ http://www.efeitonerd.com.br ]
Data     : 17/09/2012
